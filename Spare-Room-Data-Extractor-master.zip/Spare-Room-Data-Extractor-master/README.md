# Spare-Room-Data-Extractor

### Copyright (c) - Francesco Perticarari 2017

Finds rooms and people looking for accommodation on Spareroom by specifying the search areas (postcodes is preferred)

The data is then saved on two json files

I used this data to visualise statistics in SE London
